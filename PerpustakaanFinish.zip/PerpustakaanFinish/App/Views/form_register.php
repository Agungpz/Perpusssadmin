<!-- <form action="register.php" method="POST">
    <label for="nama_lengkap">Nama Lengkap</label><br>
    <input type="text" id="nama_lengkap" name="nama_lengkap" placeholder="Reyhan Fadillah" required><br><br>

    <label for="nis">NIS</label><br>
    <input type="text" id="nis" name="nis" placeholder="Masukan nomor NIS kamu..." required><br><br>

    <label for="no_wa">No. Telp</label><br>
    <input type="text" id="no_wa" name="no_whatsapp" placeholder="Masukan nomor telepon kamu..." required><br><br>

    <label for="password">Password</label><br>
    <input type="password" id="password" name="password" placeholder="Masukan kata sandi..." required><br><br>

    <input type="checkbox" id="terms" name="terms" required>
    <label for="terms">Saya menyetujui <a href="#">Syarat dan Ketentuan</a></label><br><br>

    <input type="submit" value="Daftar">
</form> -->
