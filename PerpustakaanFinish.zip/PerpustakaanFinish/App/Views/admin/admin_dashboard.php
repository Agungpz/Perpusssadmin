<?php
session_start();

// Cek apakah pengguna sudah login dan perannya admin
    // if (!isset($_SESSION['id_user']) || $_SESSION['roles'] != 'admin') {
    //     header("Location: login.php");
    //     exit();
    // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to Admin Dashboard</h1>
    <!-- Konten dashboard admin -->
</body>
</html>
