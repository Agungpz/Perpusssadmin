<?php
session_start();
// if(!isset($_SESSION['roles']) || $_SESSION['roles'] != 'admin') {
//     header("Location: login.php");
//     exit;
// }
echo "Selamat datang, Admin!";
?>
